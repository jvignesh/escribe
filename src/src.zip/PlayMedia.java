import java.io.ByteArrayInputStream;
import sun.audio.AudioPlayer;

public class PlayMedia {
	private static final AudioPlayer player = AudioPlayer.player;
	private static ByteArrayInputStream bais;
	
	public static void speak(byte[] audioData) {
		try {
			bais = new ByteArrayInputStream(audioData);
        	player.start(bais);
        	while(bais.available() > 0);
        	bais.close();
		} catch (Exception e) {
			System.out.println("Error in playing the audio class: ");
			e.printStackTrace();
		}
	}
}